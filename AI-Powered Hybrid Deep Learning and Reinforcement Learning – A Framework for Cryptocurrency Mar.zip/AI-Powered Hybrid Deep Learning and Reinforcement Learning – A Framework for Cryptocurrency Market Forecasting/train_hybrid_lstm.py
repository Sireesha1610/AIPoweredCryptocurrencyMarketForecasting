import pandas as pd
import numpy as np
import torch
import torch.nn as nn
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
import matplotlib.pyplot as plt

# 1️⃣ Load preprocessed data
df = pd.read_csv("btc_price_preprocessed_6000.csv")

# 2️⃣ Add synthetic sentiment
# +1 if price went up, -1 if price went down, 0 if no change
df['sentiment'] = df['Close'].pct_change().apply(lambda x: 1 if x > 0 else (-1 if x < 0 else 0))
df.fillna(0, inplace=True)

# 3️⃣ Feature selection (add sentiment column)
features = ['Open', 'High', 'Low', 'Close', 'Volume', 'RSI', 'SMA_10', 'Volatility', 'sentiment']
data = df[features].values

# 4️⃣ Normalize values
scaler = MinMaxScaler()
scaled = scaler.fit_transform(data)

# 5️⃣ Create sequences (past 30 → predict next Close)
def create_sequences(data, seq_len=30):
    X, y = [], []
    for i in range(len(data) - seq_len):
        X.append(data[i:i+seq_len])
        y.append(data[i+seq_len, 3])  # Close column index = 3
    return np.array(X), np.array(y)

X, y = create_sequences(scaled)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, shuffle=False)

# 6️⃣ Convert to tensors
X_train = torch.tensor(X_train, dtype=torch.float32)
y_train = torch.tensor(y_train, dtype=torch.float32)
X_test = torch.tensor(X_test, dtype=torch.float32)
y_test = torch.tensor(y_test, dtype=torch.float32)

# 7️⃣ Define LSTM model
class PriceLSTM(nn.Module):
    def __init__(self, input_dim, hidden_dim=64, num_layers=2):
        super(PriceLSTM, self).__init__()
        self.lstm = nn.LSTM(input_dim, hidden_dim, num_layers, batch_first=True)
        self.fc = nn.Linear(hidden_dim, 1)

    def forward(self, x):
        out, _ = self.lstm(x)
        out = self.fc(out[:, -1, :])
        return out

model = PriceLSTM(input_dim=X_train.shape[2])
criterion = nn.MSELoss()
optimizer = torch.optim.Adam(model.parameters(), lr=0.001)

# 8️⃣ Train the model
epochs = 30
for epoch in range(epochs):
    model.train()
    optimizer.zero_grad()
    outputs = model(X_train)
    loss = criterion(outputs.squeeze(), y_train)
    loss.backward()
    optimizer.step()
    if (epoch+1) % 5 == 0:
        print(f"Epoch [{epoch+1}/{epochs}], Loss: {loss.item():.6f}")

# 9️⃣ Evaluate
model.eval()
preds = model(X_test).detach().numpy()
y_test_np = y_test.detach().numpy()

# Reverse scale (only Close column)
close_scale = scaler.scale_[3]
close_min = scaler.min_[3]
preds_real = preds / close_scale - close_min / close_scale
y_real = y_test_np / close_scale - close_min / close_scale

# 1️⃣0️⃣ Metrics
rmse = np.sqrt(mean_squared_error(y_real, preds_real))
mae = mean_absolute_error(y_real, preds_real)
r2 = r2_score(y_real, preds_real)
print(f"\n✅ Evaluation Metrics:")
print(f"RMSE: {rmse:.2f}")
print(f"MAE: {mae:.2f}")
print(f"R² Score: {r2:.4f}")

# 1️⃣1️⃣ Plot Results
plt.figure(figsize=(10,5))
plt.plot(y_real, label="Actual Close")
plt.plot(preds_real, label="Predicted Close (Hybrid)")
plt.title("Hybrid BTC Price Prediction (LSTM + Synthetic Sentiment)")
plt.legend()
plt.show()


# ✅ Evaluation Metrics:
# RMSE: 17484.70
# MAE: 13892.15
# R² Score: 0.6819