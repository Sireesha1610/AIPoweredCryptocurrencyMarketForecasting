import pandas as pd
import numpy as np
import torch
import torch.nn as nn
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import train_test_split
import matplotlib.pyplot as plt

# 1️⃣ Load the dataset
df = pd.read_csv("btc_price_preprocessed_6000.csv")

# 2️⃣ Keep only numeric features
features = ['Open','High','Low','Close','Volume','RSI','SMA_10','Volatility']
data = df[features].values

# Normalize values to [0,1]
scaler = MinMaxScaler()
scaled = scaler.fit_transform(data)

# 3️⃣ Create sequences (past 30 → predict next close)
def create_sequences(data, seq_len=30):
    X, y = [], []
    for i in range(len(data)-seq_len):
        X.append(data[i:i+seq_len])
        y.append(data[i+seq_len, 3])  # Close column index 3
    return np.array(X), np.array(y)

X, y = create_sequences(scaled)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, shuffle=False)

# Convert to tensors
X_train = torch.tensor(X_train, dtype=torch.float32)
y_train = torch.tensor(y_train, dtype=torch.float32)
X_test = torch.tensor(X_test, dtype=torch.float32)
y_test = torch.tensor(y_test, dtype=torch.float32)

# 4️⃣ Build a simple LSTM model
class PriceLSTM(nn.Module):
    def __init__(self, input_dim, hidden_dim=64, num_layers=2):
        super(PriceLSTM, self).__init__()
        self.lstm = nn.LSTM(input_dim, hidden_dim, num_layers, batch_first=True)
        self.fc = nn.Linear(hidden_dim, 1)

    def forward(self, x):
        out, _ = self.lstm(x)
        out = self.fc(out[:, -1, :])  # last output
        return out

model = PriceLSTM(input_dim=X_train.shape[2])
criterion = nn.MSELoss()
optimizer = torch.optim.Adam(model.parameters(), lr=0.001)

# 5️⃣ Train the model
epochs = 30
for epoch in range(epochs):
    model.train()
    optimizer.zero_grad()
    outputs = model(X_train)
    loss = criterion(outputs.squeeze(), y_train)
    loss.backward()
    optimizer.step()
    if (epoch+1)%5==0:
        print(f"Epoch [{epoch+1}/{epochs}], Loss: {loss.item():.6f}")

# 6️⃣ Evaluate
model.eval()
preds = model(X_test).detach().numpy()
y_test_np = y_test.detach().numpy()

# Inverse scaling for interpretability
close_scaler = scaler.scale_[3]
close_min = scaler.min_[3]
preds_real = preds / close_scaler - close_min / close_scaler
y_real = y_test_np / close_scaler - close_min / close_scaler

# 7️⃣ Plot results
plt.figure(figsize=(10,5))
plt.plot(y_real, label="Actual Close")
plt.plot(preds_real, label="Predicted Close")
plt.legend()
plt.title("BTC Price Prediction (LSTM)")
plt.show()
