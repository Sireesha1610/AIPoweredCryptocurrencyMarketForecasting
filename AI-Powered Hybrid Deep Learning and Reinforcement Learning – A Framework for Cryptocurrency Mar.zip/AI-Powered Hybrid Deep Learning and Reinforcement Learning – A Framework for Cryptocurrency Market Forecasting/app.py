import streamlit as st
import pandas as pd
import torch
import torch.nn as nn
import numpy as np
from sklearn.preprocessing import MinMaxScaler
import matplotlib.pyplot as plt

# ----- MODEL DEFINITION -----
class PriceLSTM(nn.Module):
    def __init__(self, input_dim, hidden_dim=64, num_layers=2):
        super(PriceLSTM, self).__init__()
        self.lstm = nn.LSTM(input_dim, hidden_dim, num_layers, batch_first=True)
        self.fc = nn.Linear(hidden_dim, 1)
    def forward(self, x):
        out, _ = self.lstm(x)
        return self.fc(out[:, -1, :])

# ----- LOAD DATA -----
df = pd.read_csv("btc_price_hybrid.csv")
features = ['Open','High','Low','Close','Volume','RSI','SMA_10','Volatility','sentiment']
scaler = MinMaxScaler()
scaled = scaler.fit_transform(df[features].values)

# Create sequences
def create_sequences(data, seq_len=30):
    X = [data[i:i+seq_len] for i in range(len(data)-seq_len)]
    return np.array(X)

X_all = torch.tensor(create_sequences(scaled), dtype=torch.float32)

# Load trained model (retrain before if not saved)
model = PriceLSTM(input_dim=X_all.shape[2])
# Optionally: model.load_state_dict(torch.load("model.pth"))

# ----- STREAMLIT UI -----
st.title("💹 Hybrid LSTM-Based Bitcoin Price Predictor")
st.markdown("This demo uses **Deep Learning (LSTM)** + synthetic **sentiment signal** to forecast BTC price.")

if st.button("Predict Future Trend"):
    model.eval()
    last_seq = X_all[-1].unsqueeze(0)
    preds = []
    for _ in range(7):
        next_price = model(last_seq).item()
        preds.append(next_price)
        next_vec = torch.cat((last_seq[:, 1:, :],
                              torch.tensor([[[0]*8+[next_price]]])), dim=1)
        last_seq = next_vec
    st.success("✅ 7-Day Forecast Generated")

    # Reverse scale
    close_scale = scaler.scale_[3]
    close_min = scaler.min_[3]
    preds_real = np.array(preds) / close_scale - close_min / close_scale

    # Plot
    fig, ax = plt.subplots()
    ax.plot(preds_real, marker="o", label="Predicted Close")
    ax.set_title("Next 7-Day BTC Price Forecast")
    ax.set_xlabel("Day")
    ax.set_ylabel("Predicted Close (USD)")
    ax.legend()
    st.pyplot(fig)

# Show dataset preview
if st.checkbox("Show dataset preview"):
    st.dataframe(df.tail(10))
