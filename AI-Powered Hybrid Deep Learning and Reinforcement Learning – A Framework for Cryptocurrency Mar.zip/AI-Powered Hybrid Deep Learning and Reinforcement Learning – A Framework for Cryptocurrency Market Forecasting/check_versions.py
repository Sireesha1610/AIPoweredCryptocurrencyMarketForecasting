import importlib

libs = ["torch", "matplotlib", "flask", "numpy", "pandas", "scipy"]

for lib in libs:
    try:
        module = importlib.import_module(lib)
        version = getattr(module, "__version__", "Unknown")
        print(f"{lib}: {version}")
    except ImportError:
        print(f"{lib}: Not installed")


