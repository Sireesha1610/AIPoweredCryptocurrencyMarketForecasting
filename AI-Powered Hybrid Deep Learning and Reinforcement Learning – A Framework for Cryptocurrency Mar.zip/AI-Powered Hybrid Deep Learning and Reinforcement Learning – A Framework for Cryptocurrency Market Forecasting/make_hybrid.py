import pandas as pd

# Load your latest preprocessed dataset
df = pd.read_csv("btc_price_preprocessed_6000.csv")

# Add synthetic sentiment column
# +1 = bullish (price increased)
# -1 = bearish (price dropped)
#  0 = neutral (no change)
df['sentiment'] = df['Close'].pct_change().apply(lambda x: 1 if x > 0 else (-1 if x < 0 else 0))
df.fillna(0, inplace=True)

# Save the hybrid dataset
df.to_csv("btc_price_hybrid.csv", index=False)

print("✅ Created btc_price_hybrid.csv successfully!")
print(df.head())
