import pandas as pd
import ta   # install if needed: pip install ta

# 1️⃣ Load the 6000-row sample
df = pd.read_csv("btc_price_sample_6000.csv")

# 2️⃣ Convert timestamp to datetime
df['Timestamp'] = pd.to_datetime(df['Timestamp'], unit='s')

# 3️⃣ Set timestamp as index for resampling
df.set_index('Timestamp', inplace=True)

# 4️⃣ Resample to hourly or daily intervals (optional)
#    Hourly gives more rows, daily gives smoother trend.
df = df.resample('1H').agg({
    'Open': 'first',
    'High': 'max',
    'Low': 'min',
    'Close': 'last',
    'Volume': 'sum'
}).dropna()

# 5️⃣ Add technical indicators using the 'ta' library
df['RSI'] = ta.momentum.RSIIndicator(df['Close'], window=14).rsi()
df['SMA_10'] = ta.trend.SMAIndicator(df['Close'], window=10).sma_indicator()
df['Volatility'] = df['Close'].pct_change().rolling(10).std()

# 6️⃣ Fill missing values (first few rows)
df.fillna(method='bfill', inplace=True)

# 7️⃣ Reset index and rename column
df.reset_index(inplace=True)
df.rename(columns={'Timestamp': 'date'}, inplace=True)

# 8️⃣ Save the cleaned and enriched dataset
df.to_csv("btc_price_preprocessed_6000.csv", index=False)

print("✅ Preprocessing complete! Saved as btc_price_preprocessed_6000.csv")
print("Shape:", df.shape)
print("Columns:", df.columns.tolist())
print(df.head(10))
