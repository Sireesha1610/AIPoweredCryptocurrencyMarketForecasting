import pandas as pd

# Load the full dataset
df = pd.read_csv("btcusd_1-min_data.csv")

# Randomly select 6000 rows
df_sample = df.sample(n=6000, random_state=42)

# Sort by timestamp (to preserve time order)
df_sample = df_sample.sort_values("Timestamp").reset_index(drop=True)

# Save this smaller version
df_sample.to_csv("btc_price_sample_6000.csv", index=False)

print("✅ Saved 6000-row dataset as btc_price_sample_6000.csv")
print(df_sample.head())
